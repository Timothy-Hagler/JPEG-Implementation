function psnrVal = PSNRvalue(MSE)
disp("running psnr")
psnrVal = 20 * log10((255/(sqrt(MSE))));

end